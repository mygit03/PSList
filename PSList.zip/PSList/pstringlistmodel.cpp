#include "pstringlistmodel.h"

PStringListModel::PStringListModel(QObject *parent):QStringListModel(parent)
{

}

PStringListModel::PStringListModel(const QStringList &strings, QObject *parent):QStringListModel(strings,parent)
{

}
