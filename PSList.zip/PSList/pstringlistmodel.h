#ifndef PSTRINGLISTMODEL_H
#define PSTRINGLISTMODEL_H

#include <QObject>
#include <QStringList>
#include <QStringListModel>

class PStringListModel : public QStringListModel
{
    Q_OBJECT

public:
    PStringListModel(QObject *parent = Q_NULLPTR);
    PStringListModel(const QStringList &strings, QObject *parent = Q_NULLPTR);

    Q_INVOKABLE QString rdata(int row)
    {
        if(stringList().size()>row){
            return stringList().at(row);
        }
        return QString("");
    }
};

#endif // PSTRINGLISTMODEL_H
